<p align="center">
  <a href="https://github.com/DenverCoder1/readme-typing-svg"><img src="https://readme-typing-svg.herokuapp.com?size=21&color=F7E7E5&background=F8000000&lines=Weapon+Restrict+Map&center=true&width=500&height=50"></a>
   </p>

## Game Supported
- CS:GO

## How to Install
- Donwload Weapon-Restrict-Map and decompile the .zip, then add Weapon-Restrict-Map.smx in /csgo/addons/sourcemod/plugins

## Updates

| Version | Change-Log          |
| ------- | ------------------ |
| 4.2.0   | Added to GitHub  |
